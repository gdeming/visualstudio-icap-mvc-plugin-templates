// ============================================================================ 
// I$safeprojectname$.cs 
// Copyright (c) 2007-2019, PeopleNet Communications Corporation. 
// All rights reserved.  Unauthorized copying prohibited. 
// ============================================================================ 
 
using PNet.Icap.Platform.ProgramSdk;

namespace PNet.Icap.Plugins.$safeprojectname$
{
    /// <summary>
    /// Interface I$safeprojectname$.
    /// </summary>
    public interface I$safeprojectname$ : IService
    {
        // TODO: Add the service interface.
    }
}