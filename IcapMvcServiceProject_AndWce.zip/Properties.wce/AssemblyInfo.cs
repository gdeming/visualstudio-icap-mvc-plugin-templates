// ============================================================================ 
// AssemblyInfo.cs 
// Copyright (c) 2007-2019, PeopleNet Communications Corporation. 
// All rights reserved.  Unauthorized copying prohibited. 
// ============================================================================ 
 
﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PNet.$safeprojectname$")]
[assembly: AssemblyDescription("PeopleNet ICAP $safeprojectname$ Plugin for Windows CE")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.0.0.0")]
//[assembly: AssemblyFileVersion("0.0.0.0")] // use AssemblyVersion for AssemblyFileVersion
//[assembly: AssemblyInformationalVersion("0.0.0.0")] // use AssemblyVersion for AssemblyInformationalVersion

// Communism
[assembly: ComVisible(false)]
[assembly: Guid("$guid2$")]
